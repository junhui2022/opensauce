#!/bin/bash
echo "이름과 생일 또는 전화번호를 입력하세요"
read info
echo "$info" >> DB.txt
echo "DB.txt에 저장되었습니다."
