#!/bin/bash
echo "Enter the name to search: "
read name

grep -i $name DB.txt
