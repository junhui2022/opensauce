#!/bin/bash
echo "Enter two numbers: "
read num1 num2
echo "Enter an operator (+,-): "
read op

case $op in
    "+") echo "$num1 + $num2 = `expr $num1 + $num2`";;
    "-") echo "$num1 - $num2 = `expr $num1 - $num2`";;
    *) echo "Invalid operator";;
esac
