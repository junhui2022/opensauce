#!/bin/bash
echo "숫자를 입력하세요"
read num
for i in `seq 1 $num`
do
echo "hello world"
done
