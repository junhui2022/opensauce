#!/bin/bash
echo "Enter a name for the new directory: "
read dirName
if [ -d $dirName ]
then
    echo "Directory already exists"
else
    mkdir $dirName
fi
cd $dirName
for i in 1 2 3 4 5
do
    touch file$i
done
tar -cvf files.tar file*
cd ..
mkdir newDir
mv $dirName/files.tar newDir
cd newDir
tar -xvf files.tar
ls
cd ..
rm -r $dirName newDir

