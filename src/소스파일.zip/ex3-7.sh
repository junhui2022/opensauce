#!/bin/bash
if [ $# -ne 1 ]; then
    echo "Usage: $0 <directory>"
    exit 1
fi

if [ ! -d $1 ]; then
    echo "Error: $1 is not a directory"
    exit 1
fi

cd $1

for i in {1..5}; do
    touch $i.txt
    mkdir $i
    ln -s $i.txt $i/$i.txt
done

exit 0
