#!/bin/bash
echo "리눅스가 재미있나요?"
read answer

case $answer in
    yes|y|Y|YES) echo "그렇군요!";;
    [nN][oO]) echo "아쉽군요!";;
    *) echo "잘 모르겠습니다!";;
esac
